-- AlterTable
ALTER TABLE "Usuario" ALTER COLUMN "updatedAt" DROP NOT NULL;
